# WATT — Workforce Assessment for Transition & Talent

This is the published site artifact for GitHub Pages.

- Start file: `index.html`
- Jekyll disabled via `.nojekyll`
- Build: 2025-08-31 14:25:39Z
